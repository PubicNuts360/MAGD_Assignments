
  //INSTANCE VARIABLES

//mouse values
let mx = 0;
let my = 0;
let px = 0;
let py = 0;
//frame value
let fr = 0;

function setup() {
  createCanvas(1000, 1000);
  background(220);
  
  // initial frameRate value
	let fr = 30;
	frameRate(fr);

}

function draw() {
  
   
  
    let fr = sqrt(75);
	frameRate(fr);
  
  // show output of variable fr value, used for frameRate in console

	print(fr);


// set variables to updated values based on current and previous mouse position
	let mx = mouseX;
	let my = mouseY;
	let px = pmouseX;
	let py = pmouseY;
  
  
 
  colorMode(RGB, 255, 255, 255, 1);
  
  // stroke is determined by the absolute value of both the x and y creating a bulge effect
   var distFromCenter = dist(mx, my, 500, 500);
  var weight = abs(mx + my) - 10;
	strokeWeight (weight);

// color is determined by location
	stroke(mx, my, distFromCenter, 0.75);


	line(mx, my, px, py);

	
  

  
  
}