let button;
let light = 0;
var color_button; 
   
function change_background() { 
      
    r = random(255); 
    g = random(255); 
    b = random(255); 
      
    // Set a random background-color 
    background(r, g, b); 
} 

function setup() {
  createCanvas(1500, 700);
   background(156);
  strokeWeight(4);
  //B=U=T=T=O=N==============
    color_button = createButton("Change Color"); 
    color_button.position(150, 200); 
    color_button.mouseClicked(change_background); 
  //=========================

    input = createInput();
  input.position(20, 65);

  button = createButton('submit');
  button.position(input.x + input.width, 65);
  button.mousePressed(greet);

  greeting = createElement('h2', 'what is your ID?');
  greeting.position(20, 5);

  textAlign(CENTER);
  textSize(50);
}

function greet() {
  const name = input.value();
  greeting.html('hello ' + name + '!');
  input.value('');

  for (let i = 0; i < 200; i++) {
    push();
    fill(random(255), 255, 255);
    translate(random(width), random(height));
    rotate(random(2 * PI));
    text(name, 0, 0);
    pop();
  }
}

function draw() {
  ellipse(mouseX, mouseY, 33, 33);

      if ((keyIsPressed == true) && (key == 'a')) {
    line(250, 225, 250, 275);
  }
  else { 
    ellipse(250, 250, 250, 250);
  }

    

}

