
var img;
var img2;
var start = "PRESS START";

function preload() {

	img = loadImage("Terminator.png");
	img2 = loadImage("pixelChunkWarrior.png")

		textFont("Press Start 2P");

	fill(0);

	stroke(255);

}

function setup () {

	createCanvas(1000, 700);

}

function draw () {
background(100);
	image(img, mouseX, mouseY, mouseX * 2, mouseY * 2);
	image(img2, mouseY -5, mouseX, 100, 100);

	textSize(25);

	text(start, 375, 0, 500, 100);
}